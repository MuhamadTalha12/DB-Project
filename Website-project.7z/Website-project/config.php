<?php
$servername='127.0.0.1';
$username='root';
$password='';
$dbname = "Shop";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
die('Could not Connect MySql Server:');
}
?>