# Website-project
Course project which uses HTML, CSS ,Java Script and PHP with SQL to implement functional shoping website.
### this a course project for King Saud University CSC456
